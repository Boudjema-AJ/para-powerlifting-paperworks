import React from "react";

function Results() {
  return (
    <div className="container">
      <h1 className="text-3xl font-bold mb-8 text-center text-blue-800">
        Competition Results
      </h1>
      <p>This section is under development. Add results management logic here.</p>
    </div>
  );
}

export default Results;